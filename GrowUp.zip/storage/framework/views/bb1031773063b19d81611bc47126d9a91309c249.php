
<?php $__env->startSection('title', 'Detail Kelas | GrowUp'); ?>

<?php $__env->startSection('dashboard_content'); ?>
    
    <?php echo $__env->make('sessions.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="section-title">
        <h1>
            <i class="uil uil-eye"></i>
            Detail Kelas
        </h1>
        <div class="line"></div>
    </div>

    
    <div class="course-heading">
        <span class="title mb-1"><?php echo e($course->title); ?></span>
        <small class="badge bg-green"><?php echo e($course->category->title); ?></small>
        <small
            class="text-red fw-bold"><?php echo e($course->price == null ? 'Gratis' : 'Rp' . number_format($course->price)); ?></small>
        <span class="description mt-3"><?php echo e($course->description); ?></span>
    </div>

    
    <div class="class-info">
        <div class="row">
            <div class="class-info-item col-md-3 col-6">
                <div>
                    <b>Kelas Dimulai</b>
                    <br>
                    <i class="uil uil-hourglass me-1"></i>
                    <?php echo e(\Carbon\Carbon::parse($course->started_at)->format('d M Y')); ?>

                </div>
            </div>
            <div class="class-info-item col-md-3 col-6">
                <div>
                    <b>Kelas Berakhir</b>
                    <br>
                    <i class="uil uil-calendar-alt me-1"></i>
                    <?php echo e(\Carbon\Carbon::parse($course->ended_at)->format('d M Y')); ?>

                </div>
            </div>
            <div class="class-info-item col-md-3 col-6">
                <div>
                    <b>Total Mentee</b>
                    <br>
                    <i class="uil uil-users-alt me-1"></i><?php echo e($transaction->count()); ?> /
                    <?php echo e($course->max_mentee); ?>

                </div>
            </div>
            <div class="class-info-item col-md-3 col-6">
                <div>
                    <b>Rating Kelas</b>
                    <br>
                    <?php for($i = 1; $i <= $course->rating; $i++): ?>
                        <i class="uis uis-star text-yellow"></i>
                    <?php endfor; ?>
                    
                </div>
            </div>
        </div>
    </div>

    
    <div class="session">
        <a href="#" class="btn btn-dark btn-sm" data-bs-toggle="modal" data-bs-target="#createMeet"><i
                class="uil uil-plus me-1"></i>Buat Pertemuan</a>
        <?php if($sessions->count() != 0): ?>
            <div class="table-wrapper bg-light">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="th-20">#</th>
                            <th class="th-25">Judul Materi</th>
                            <th class="th-30">Deskripsi Materi</th>
                            <th class="th-15 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="d-block fw-bold">Pertemuan <?php echo e($loop->iteration); ?></span>
                                    <small><?php echo e(\Carbon\Carbon::parse($session->schedule)->format('d M') . ' (' . $session->time . ')'); ?></small>
                                </td>
                                <td>
                                    <span class="d-block"><?php echo e(substr($session->title, 0, 35) . '...'); ?></span>
                                    <a href="<?php echo e($session->meeting_link); ?>" class="text-sm text-decoration-none"><i
                                            class="uil uil-meeting-board me-1"></i>Join Meeting</a>
                                </td>
                                <td><?php echo e(substr($session->description, 0, 50) . '...'); ?></td>
                                <td class="action-btn-table">
                                    <a href="<?php echo e(route('downloadResource', $session->id)); ?>" class="text-dark"><i
                                            class="uil uil-import"></i></a>
                                    <a href="<?php echo e(url('mentor/session/edit/' . $session->id . '/' . $loop->iteration)); ?>"
                                        class="text-primary mx-1"><i class="uil uil-edit"></i></a>
                                    <a href="#" data-uri="<?php echo e(route('deleteSession', $session->id)); ?>"
                                        class="text-danger" data-bs-toggle="modal"
                                        data-bs-target="#confirmDeleteModal"><i class="uil uil-trash-alt"></i></a>
                                    <a href="#" class="text-success"><i class="uil uil-check-circle"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning mt-3">Belum ada jadwal pertemuan di kelas ini</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/courses/show.blade.php ENDPATH**/ ?>