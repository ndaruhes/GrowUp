<?php $user = Auth::user(); ?>


<?php $__env->startSection('title', 'Dashboard ' . $user->role . ' | GrowUp'); ?>
<?php $__env->startSection('cssExternal'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/user_home.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_content'); ?>
    
    <div class="col-md-10 mb-3">
        <div class="row align-items-center">
            <div class="col-md-2 col-3">
                <img src="<?php echo e(asset('/images/avatar.png')); ?>" alt="avatar.png" class="w-100 shadow-sm rounded-circle">
            </div>
            <div class="col-md-10 col-9 p-0 modal-user-info">
                <span class="fs-5"><?php echo e($user->name); ?></span>
                <small class="badge bg-green"><?php echo e($user->role); ?></small>
            </div>
        </div>
    </div>
    <div class="row">
        <?php if($user->role == 'Mentor'): ?>
            <div class="col-md-4 col-6 item">
                <a href="#" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/wallet.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Pendapatan</span>
                            <span class="subtitle price text-green fw-bold">
                                Rp<?php echo e(number_format($salary)); ?>

                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-6 item">
                <a href="<?php echo e(url(strtolower($user->role) . '/courses')); ?>" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/class.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Total Kelas</span>
                            <span class="subtitle">
                                <?php echo e($courses->count()); ?> Kelas
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-6 item">
                <a href="#" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/users.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Total Mentee</span>
                            <span class="subtitle">
                                <?php echo e($transactions->count()); ?> Mentee
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-6 item">
                <a href="#" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/forum.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Total Forum</span>
                            <span class="subtitle">
                                20 Diskusi
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-6 item">
                <a href="#" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/rating.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Rating Kelas</span>
                            <span class="subtitle">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="uis uis-star text-yellow"></i>
                                <?php endfor; ?>
                            </span>
                        </div>
                    </div>
                </a>
            </div>
        <?php else: ?>
            <div class="col-md-4 col-6 item">
                <a href="<?php echo e(url(strtolower($user->role) . '/courses')); ?>" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/class.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Total Kelas</span>
                            <span class="subtitle">
                                <?php echo e($transactions->count()); ?> Kelas
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-6 item">
                <a href="#" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/users.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Total Mentor</span>
                            <span class="subtitle">
                                <?php echo e($transactions->count()); ?> Mentor
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-6 item">
                <a href="#" class="col-md-12 item-content">
                    <div class="row align-items-center">
                        <div class="col-4 icon">
                            <img src="<?php echo e(asset('images/dashboard-icon/forum.png')); ?>" class="w-100" alt="icon">
                        </div>
                        <div class="col-8 text">
                            <span class="title">Total Forum</span>
                            <span class="subtitle">
                                20 Diskusi
                            </span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/pages/userHome.blade.php ENDPATH**/ ?>