
<?php $__env->startSection('title', 'Dashboard | GrowUp'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php
    $currURL = explode('/', Request::path());
    $user = Auth::user();
    ?>

    
    <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        
        <div class="dashboard-menu">
            <div class="dashboard-menu-panel">
                <a href="<?php echo e($user->role == 'Mentor' ? url('mentor') : url('mentee')); ?>"
                    class="btn bg-outline-green btn-sm"><i class="uil uil-apps me-1"></i>Dashboard
                </a>
                <a href="<?php echo e($user->role == 'Mentor' ? url('mentor/courses') : url('mentee/courses')); ?>"
                    class="btn bg-outline-green btn-sm"><i
                        class="uil uil-notebooks me-1"></i><?php echo e($user->role == 'Mentor' ? 'Kelola Kelas' : 'Kelas Saya'); ?>

                </a>
                <a href="<?php echo e($user->role == 'Mentor' ? url('mentor/forum') : url('mentee/forum')); ?>"
                    class="btn bg-outline-green btn-sm"><i class="uil uil-comments-alt me-1"></i>Forum Diskusi
                </a>
                <a href="/profile" class="btn bg-outline-green btn-sm"><i class="uil uil-user-circle me-1"></i>Profil
                </a>
            </div>
        </div>

        
        <div class="row">
            <div class="col-md-7 content-left">
                <?php echo $__env->yieldContent('dashboard_content'); ?>
            </div>
            <div class="col-md-5 content-right">
                <div class="grafik">
                    <h4 class="fw-bold"><i class="uil uil-analytics me-1"></i>Grafik Pencapaian</h4>
                    <hr>
                    <canvas class="mentorChart" class="w-100" height="150"></canvas>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>