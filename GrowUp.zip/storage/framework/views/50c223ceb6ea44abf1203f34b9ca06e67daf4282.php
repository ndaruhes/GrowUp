
<?php $__env->startSection('title', 'Dashboard | GrowUp'); ?>

<?php
$currURL = explode('/', Request::path());
?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        
        <?php echo $__env->make('layouts.dashboardMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div class="row">
            <div class="col-md-6 content-left">
                <?php if($currURL[1] != null && $currURL[1] == 'courses'): ?>
                    <?php echo $__env->make('courses.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    <h1>Halo</h1>
                <?php endif; ?>
            </div>
            <div class="col-md-6 content-right">
                <img src="<?php echo e(asset('images/dashboard.png')); ?>" alt="dashboard.png" class="w-100">
            </div>
        </div>
    </div>


    
    

    
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/home.blade.php ENDPATH**/ ?>