<h4>Grafik Pencapaian</h4>
<hr>
<canvas class="mentorChart" class="w-100" height="150"></canvas>

<?php $__env->startSection('jsExternal'); ?>
    <script src="<?php echo e(asset('js/chart.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/layouts/chart.blade.php ENDPATH**/ ?>