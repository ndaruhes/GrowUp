

<?php $__env->startSection('title', $course->title . ' | GrowUp'); ?>
<?php $__env->startSection('cssExternal'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/course_detail.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.checkout', ['course' => $course], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="container">
        <div class="row">
            <div class="col-md-4 info">
                <?php if(explode('/', $course->cover)[0] != 'https:'): ?>
                    <img src="<?php echo e($course->cover != null ? asset('storage/images/cover/' . $course->cover) : asset('images/no-image.png')); ?>"
                        alt="<?php echo e($course->title); ?>" class="w-100">
                <?php else: ?>
                    <img src="<?php echo e($course->cover); ?>" alt="<?php echo e($course->title); ?>" class="w-100">
                <?php endif; ?>
                <span class="title mb-1"><?php echo e($course->title); ?></span>
                <span
                    class="mentor"><?php echo e(Auth::user() && Auth::user()->id == $course->mentor_id? 'Kamu adalah mentor di kelas ini 👏': $course->user->name); ?></span>
                <small class="category badge bg-green"><?php echo e($course->category->title); ?></small>
                <small class="price text-red fw-bold">
                    <?php echo e($course->price != null ? 'Rp' . number_format($course->price) : 'Gratis'); ?>

                </small>
                <span class="description mt-3"><?php echo e($course->description); ?></span>
                <?php if(!Auth::user()): ?>
                    <a href="#" class="btn d-block w-100 bg-red" data-bs-toggle="modal" data-bs-target="#loginModal">Gabung
                        Kelas Sekarang</a>
                <?php elseif($hasTransaction == null): ?>
                    <a href="#" class="btn d-block w-100 bg-red" data-bs-toggle="modal"
                        data-bs-target="#checkoutModal">Gabung Kelas Sekarang</a>
                <?php elseif($hasTransaction != null): ?>
                    <a href="#" class="btn bg-secondary text-white w-100 cursor-disabled">Sudah Bergabung</a>
                <?php endif; ?>
            </div>

            <div class="col-md-7 detail">
                <div class="container">
                    <div class="row">
                        
                        <div class="class-info">
                            <div class="row">
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Kelas Dimulai</b>
                                        <br>
                                        <i class="uil uil-hourglass me-1"></i>
                                        <?php echo e(\Carbon\Carbon::parse($course->started_at)->format('d M Y')); ?>

                                    </div>
                                </div>
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Kelas Berakhir</b>
                                        <br>
                                        <i class="uil uil-calendar-alt me-1"></i>
                                        <?php echo e(\Carbon\Carbon::parse($course->ended_at)->format('d M Y')); ?>

                                    </div>
                                </div>
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Total Mentee</b>
                                        <br>
                                        <i class="uil uil-users-alt me-1"></i><?php echo e($transaction->count()); ?> /
                                        <?php echo e($course->max_mentee); ?>

                                    </div>
                                </div>
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Rating Kelas</b>
                                        <br>
                                        <?php for($i = 1; $i <= $course->rating; $i++): ?>
                                            <i class="uis uis-star text-yellow"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <?php if($sessions->count() != null): ?>
                            <div class="accordion accordion-flush" id="accordionFlushSession">
                                <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-heading<?php echo e($session->id); ?>">
                                            <button class="accordion-button collapsed d-flex justify-content-between"
                                                type="button" data-bs-toggle="collapse"
                                                data-bs-target="#flush-collapse<?php echo e($session->id); ?>" aria-expanded="false"
                                                aria-controls="flush-collapse<?php echo e($session->id); ?>">
                                                <b>Pertemuan <?php echo e($loop->iteration); ?></b> &nbsp;
                                                (<?php echo e(\Carbon\Carbon::parse($session->schedule)->format('d M') . ', ' . $session->time); ?>)
                                            </button>
                                        </h2>
                                        <div id="flush-collapse<?php echo e($session->id); ?>"
                                            class="accordion-collapse collapse <?php if($loop->iteration == 1): ?> show <?php endif; ?>"
                                            aria-labelledby="flush-heading<?php echo e($session->id); ?>"
                                            data-bs-parent="#accordionFlushSession">
                                            <div class="accordion-body">
                                                <p>
                                                    <b>Topik Materi</b>
                                                    <span><?php echo e($session->title); ?></span>
                                                </p>
                                                <p>
                                                    <b>Deskripsi Materi</b>
                                                    <span><?php echo e($session->description); ?></span>
                                                </p>
                                                <p>
                                                    <b>Link Meeting</b>
                                                    <a class="text-decoration-none d-block cursor-pointer"
                                                        <?php if(!Auth::user()): ?> data-bs-toggle="modal" data-bs-target="#loginModal" <?php elseif($hasTransaction == null): ?> data-bs-toggle="modal" data-bs-target="#gabungKelasModal" <?php else: ?> href="<?php echo e($session->meeting_link); ?>" target="_blank" <?php endif; ?>>Join
                                                        Kelas<i class="uil uil-presentation-play ms-1"></i></a>
                                                </p>
                                                <p>
                                                    <b>Materi Pembelajaran</b>
                                                    <a class="text-decoration-none d-block cursor-pointer"
                                                        <?php if(!Auth::user()): ?> data-bs-toggle="modal" data-bs-target="#loginModal" <?php elseif($hasTransaction == null): ?> data-bs-toggle="modal" data-bs-target="#gabungKelasModal" <?php else: ?> href="<?php echo e(route('downloadResource', $session->id)); ?>" <?php endif; ?>>Unduh
                                                        Materi<i class="uil uil-download-alt ms-1"></i></a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">Mentor belum mengatur pertemuan dikelas ini. Ditunggu aja ya 😁
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/pages/detailCourse.blade.php ENDPATH**/ ?>