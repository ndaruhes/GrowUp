
<?php $__env->startSection('title', 'Dashboard | GrowUp'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php $currURL = explode('/', Request::path()); ?>

    
    <?php echo $__env->make('layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        
        <?php echo $__env->make('layouts.dashboardMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div class="row">
            <div class="col-md-7 content-left">
                <?php echo $__env->yieldContent('dashboard_content'); ?>
            </div>
            <div class="col-md-5 content-right">
                <img src="<?php echo e(asset('images/dashboard.png')); ?>" alt="dashboard.png" class="w-100">
            </div>
        </div>
    </div>


    
    

    
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/dashboard.blade.php ENDPATH**/ ?>