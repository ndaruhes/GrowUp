<div class="container bg-light banner">
    <h1>Halo <?php echo e(Auth::user()->name); ?> 👋</h1>
    <p class="mb-4">
        <?php if(Auth::user()->role == 'Mentor'): ?>
            Yuk kelola course kamu terlebih dahulu, course yang dikelola dan ditata dengan baik dapat meningkatkan
            ketertarikan loh. Semoga bermanfaat :D
        <?php else: ?>
            Terus belajar kembangkan keterampilanmu dan tetap semangat. Semoga harimu menyenangkan :D
        <?php endif; ?>
    </p>
    <a href="<?php echo e(url('/')); ?>" class="btn bg-red text-white">
        <i class="uil uil-estate me-1"></i>Kembali Ke Beranda
    </a>
</div>
<?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/layouts/banner.blade.php ENDPATH**/ ?>