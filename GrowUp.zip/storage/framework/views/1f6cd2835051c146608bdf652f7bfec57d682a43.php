
<?php $user = Auth::user(); ?>
<?php $__env->startSection('title', $user->role == 'Mentor' ? 'Kelola Kelas' : 'Kelas Saya' . ' | GrowUp'); ?>

<?php $__env->startSection('dashboard_content'); ?>
    
    <?php if($user->role == 'Mentor'): ?>
        <?php echo $__env->make('courses.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <div class="section-title">
        <h1>
            <i class="uil uil-notebooks"></i>
            Daftar Kelas
        </h1>
        <div class="line"></div>
        <?php if($user->role == 'Mentor'): ?>
            <button class="btn btn-dark btn-sm add-btn" data-bs-toggle="modal" data-bs-target="#addModal">Buat Kelas<i
                    class="uil uil-plus ms-1"></i></button>
        <?php endif; ?>
    </div>

    
    <?php if($courses->count() != 0): ?>
        <div class="table-wrapper bg-light">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th class="th-25">Sampul</th>
                        <th class="th-30">Nama Kelas</th>
                        <th class="th-30">Deskripsi Kelas</th>
                        <th class="th-15 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->role == 'Mentor'): ?>
                            <tr>
                                <td class="fw-bold"><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if(explode('/', $course->cover)[0] != 'https:'): ?>
                                        <img src="<?php echo e($course->cover != null ? asset('storage/images/cover/' . $course->cover) : asset('images/no-image.png')); ?>"
                                            alt="<?php echo e($course->title); ?>" class="rounded shadow-sm w-100">
                                    <?php else: ?>
                                        <img src="<?php echo e($course->cover); ?>" alt="<?php echo e($course->title); ?>"
                                            class="rounded shadow w-100">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="d-block"><?php echo e(substr($course->title, 0, 35) . '...'); ?></span>
                                    <small class="badge bg-green">
                                        <?php echo e($course->price == null ? 'Gratis' : 'Rp' . number_format($course->price)); ?>

                                    </small>
                                    <small class="badge bg-red">
                                        <?php echo e($course->category->title); ?>

                                    </small>
                                </td>
                                <td>
                                    <span class="d-block"><?php echo e(substr($course->description, 0, 40) . '...'); ?></span>
                                    <small class="badge bg-green">
                                        <i class="uil uil-users-alt me-1"></i> <?php echo e($course->transaction->count()); ?> /
                                        <?php echo e($course->max_mentee); ?>

                                    </small>
                                </td>
                                <td class="action-btn-table">
                                    <a href="<?php echo e(route('showCourse', $course->id)); ?>" class="text-dark"><i
                                            class="uil uil-eye"></i></a>
                                    <?php if($user->role == 'Mentor'): ?>
                                        <a href="<?php echo e(route('editCourse', $course->id)); ?>" class="text-primary mx-1"><i
                                                class="uil uil-edit"></i></a>
                                        <a href="#" data-uri="<?php echo e(route('deleteCourse', $course->id)); ?>"
                                            class="text-danger" data-bs-toggle="modal"
                                            data-bs-target="#confirmDeleteModal"><i class="uil uil-trash-alt"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td class="fw-bold"><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if(explode('/', $course->course->cover)[0] != 'https:'): ?>
                                        <img src="<?php echo e($course->course->cover != null? asset('storage/images/cover/' . $course->course->cover): asset('images/no-image.png')); ?>"
                                            alt="<?php echo e($course->course->title); ?>" class="rounded shadow-sm w-100">
                                    <?php else: ?>
                                        <img src="<?php echo e($course->course->cover); ?>" alt="<?php echo e($course->course->title); ?>"
                                            class="rounded shadow w-100">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span
                                        class="d-block"><?php echo e(substr($course->course->title, 0, 35) . '...'); ?></span>
                                    <small class="badge bg-green">
                                        <?php echo e($course->price == null ? 'Gratis' : 'Rp' . number_format($course->price)); ?>

                                    </small>
                                    <small class="badge bg-red">
                                        <?php echo e($course->course->category->title); ?>

                                    </small>
                                </td>
                                <td>
                                    <span
                                        class="d-block"><?php echo e(substr($course->course->description, 0, 40) . '...'); ?></span>
                                    <small class="badge bg-green">
                                        <i class="uil uil-users-alt me-1"></i>
                                        <?php echo e($course->course->transaction->count()); ?> /
                                        <?php echo e($course->course->max_mentee); ?>

                                    </small>
                                </td>
                                <td class="action-btn-table">
                                    <?php if($user->role == 'Mentor'): ?>
                                        <a href="<?php echo e(route('detailCourse', $course->course->id)); ?>"
                                            class="text-dark"><i class="uil uil-eye"></i></a>
                                        <a href="<?php echo e(route('editCourse', $course->id)); ?>" class="text-primary mx-1"><i
                                                class="uil uil-edit"></i></a>
                                        <a href="#" data-uri="<?php echo e(route('deleteCourse', $course->id)); ?>"
                                            class="text-danger" data-bs-toggle="modal"
                                            data-bs-target="#confirmDeleteModal"><i class="uil uil-trash-alt"></i></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('detailCourse', $course->course->id)); ?>"
                                            class="badge bg-dark text-decoration-none">
                                            <i class="uil uil-eye me-1"></i>Lihat
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <?php echo e($user->role == 'Mentor' ? 'Kamu belum memiliki kelas apapun' : 'Kamu belum mengikuti kelas apapun'); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/courses/index.blade.php ENDPATH**/ ?>