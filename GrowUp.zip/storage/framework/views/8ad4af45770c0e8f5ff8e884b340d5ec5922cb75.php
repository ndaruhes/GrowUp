

<?php $__env->startSection('title', 'Profil | GrowUp'); ?>


<?php $__env->startSection('dashboard_content'); ?>
    <div class="section-title">
        <h1><i class="uil uil-user-circle me-1"></i>Profil Kamu</h1>
        <div class="line"></div>
    </div>
    <div class="user-info">
        <span class="title"><i class="uil uil-user me-1"></i>Nama Lengkap</span>
        <span class="value"><?php echo e(Auth::user()->name); ?></span>
    </div>
    <div class="user-info">
        <span class="title"><i class="uil uil-envelope me-1"></i>Alamat E-Mail</span>
        <span class="value"><?php echo e(Auth::user()->email); ?></span>
    </div>
    <div class="user-info">
        <span class="title"><i class="uil uil-user-md me-1"></i>Peran Pengguna</span>
        <span class="value"><?php echo e(Auth::user()->role); ?></span>
    </div>
    <div class="user-info">
        <span class="title"><i class="uil uil-calendar-alt me-1"></i>Tanggal Registrasi</span>
        <span class="value"><?php echo e(\Carbon\Carbon::parse(Auth::user()->created_at)->format('d M Y')); ?></span>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/auth/profile.blade.php ENDPATH**/ ?>