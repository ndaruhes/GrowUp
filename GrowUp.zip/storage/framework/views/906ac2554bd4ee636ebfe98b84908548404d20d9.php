

<?php $__env->startSection('title', $category->title . ' Courses | GrowUp'); ?>
<?php $__env->startSection('cssExternal'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/explore.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container wrapper">
        <div class="explore">
            <div class="explore-heading">
                <div class="title d-flex align-items-center">
                    <span>Eksplor Semua Kelas</span>
                    <img src="<?php echo e(asset('images/nerd.png')); ?>" alt="nerd.png">
                </div>
                <p class="description">Siap ambil bagian dan bersaing di industri 4.0? Ayo belajar dan tingkatkan
                    keterampilanmu bersama mentor berpengalaman GrowUp. Cari dan eksplor kelas kesukaanmu.</p>

                
                <form action="<?php echo e(route('searchCourse')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="search"
                            name="search" placeholder="Cari kelas disini..." value="<?php echo e(old('search')); ?>">
                        <label for="search">Cari kelas disini...</label>
                    </div>
                </form>

                
                <div class="categories-menu">
                    <div class="categories-menu-panel">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('courseCategory', $data->id)); ?>"
                                class="btn bg-outline-green btn-sm"><?php echo e($data->title); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            
            <div class="courses">
                <div class="category-title d-flex align-items-center">
                    <img src="<?php echo e($category->icon); ?>" alt="<?php echo e($category->icon); ?>">
                    <span><?php echo e($category->title); ?></span>
                </div>
                <?php if($courses->count() != 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-12">
                                <a href="<?php echo e(route('detailCourse', $course->id)); ?>"
                                    class="col-md-12 item-content d-flex align-items-center">
                                    <div class="row align-items-center">
                                        <div class="col-md-12 col-5 image">
                                            <?php if(explode('/', $course->cover)[0] != 'https:'): ?>
                                                <img src="<?php echo e($course->cover != null ? asset('storage/images/cover/' . $course->cover) : asset('images/no-image.png')); ?>"
                                                    alt="<?php echo e($course->title); ?>" class="w-100">
                                            <?php else: ?>
                                                <img src="<?php echo e($course->cover); ?>" alt="<?php echo e($course->title); ?>"
                                                    class="w-100">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-12 col-7 text">
                                            <span class="title"><?php echo e($course->title); ?></span>
                                            <span class="mentor"><?php echo e($course->user->name); ?></span>
                                            <span
                                                class="price"><?php echo e($course->price == null ? 'Gratis' : 'Rp' . number_format($course->price)); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">Belum ada kelas di kategori ini<i class="uil uil-sad-squint ms-1"></i>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/pages/courseCategory.blade.php ENDPATH**/ ?>