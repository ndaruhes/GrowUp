

<?php $__env->startSection('title', $course->title . ' | GrowUp'); ?>
<?php $__env->startSection('cssExternal'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/course_detail.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.checkout', ['course' => $course], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="container">
        <div class="row">
            <div class="col-md-4 info">
                <?php if(explode('/', $course->cover)[0] != 'https:'): ?>
                    <img src="<?php echo e($course->cover != null ? asset('storage/images/cover/' . $course->cover) : asset('images/no-image.png')); ?>"
                        alt="<?php echo e($course->title); ?>" class="w-100">
                <?php else: ?>
                    <img src="<?php echo e($course->cover); ?>" alt="<?php echo e($course->title); ?>" class="w-100">
                <?php endif; ?>
                <span class="title mb-1"><?php echo e($course->title); ?></span>
                <span
                    class="mentor"><?php echo e(Auth::user() && Auth::user()->id == $course->mentor_id? 'Kamu adalah mentor di kelas ini 👏': $course->user->name); ?></span>
                <small class="category badge bg-green"><?php echo e($course->category->title); ?></small>
                <small class="price text-red fw-bold">
                    <?php echo e($course->price != null ? 'Rp' . number_format($course->price) : 'Gratis'); ?>

                </small>
                <span class="description mt-3"><?php echo e($course->description); ?></span>
                <?php if(!Auth::user()): ?>
                    <a href="#" class="btn d-block w-100 bg-red" data-bs-toggle="modal" data-bs-target="#loginModal">Gabung
                        Kelas Sekarang</a>
                <?php elseif($hasTransaction == null): ?>
                    <a href="#" class="btn d-block w-100 bg-red" data-bs-toggle="modal"
                        data-bs-target="#checkoutModal">Gabung Kelas Sekarang</a>
                <?php elseif($hasTransaction != null): ?>
                    <a href="#" class="btn bg-secondary text-white w-100 cursor-disabled">Sudah Bergabung</a>
                <?php endif; ?>
            </div>

            <div class="col-md-7 detail">
                <div class="container">
                    <div class="row">
                        
                        <div class="class-info">
                            <div class="row">
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Kelas Dimulai</b>
                                        <br>
                                        <i class="uil uil-hourglass me-1"></i>
                                        <?php echo e(\Carbon\Carbon::parse($course->started_at)->format('d M Y')); ?>

                                    </div>
                                </div>
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Kelas Berakhir</b>
                                        <br>
                                        <i class="uil uil-calendar-alt me-1"></i>
                                        <?php echo e(\Carbon\Carbon::parse($course->ended_at)->format('d M Y')); ?>

                                    </div>
                                </div>
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Total Mentee</b>
                                        <br>
                                        <i class="uil uil-users-alt me-1"></i><?php echo e($transaction->count()); ?> /
                                        <?php echo e($course->max_mentee); ?>

                                    </div>
                                </div>
                                <div class="class-info-item col-md-3 col-6">
                                    <div>
                                        <b>Rating Kelas</b>
                                        <br>
                                        <?php for($i = 1; $i <= $course->rating; $i++): ?>
                                            <i class="uis uis-star text-yellow"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <?php if($forums->count() != null): ?>
                            <div class="table-wrapper bg-light">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th class="th-1">#</th>
                                            <th class="th-25">Judul Forum</th>
                                            <th class="th-5">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <span class="d-block fw-bold"><?php echo e($loop->iteration); ?></span>
                                                </td>
                                                <td><?php echo e($forum->title); ?></td>
                                                <td class="action-btn-table">
                                                    <a href="<?php echo e(route('thread', $forum->id)); ?>"
                                                        class="badge bg-dark text-decoration-none">
                                                        Lihat Forum
                                                        <i class="uil uil-eye ms-1"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">Mentor belum mengatur pertemuan dikelas ini. Ditunggu aja ya 😁
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Sunib\Student Affairs\BNCC\BNCC Elite Team\Competitions\IO UNTAR 2022\GrowUp\resources\views/forum/detail.blade.php ENDPATH**/ ?>