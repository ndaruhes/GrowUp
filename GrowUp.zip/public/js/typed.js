/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/js/typed.js":
/*!*******************************!*\
  !*** ./resources/js/typed.js ***!
  \*******************************/
/***/ (() => {

eval("// TYPED\nvar typed = new Typed('#slogan', {\n  strings: ['A New Different Way to Improve Your Skills', 'Let\\'s Join and Start Growing with Us...'],\n  smartBackspace: true,\n  typeSpeed: 50,\n  backSpeed: 30,\n  loop: true,\n  startDelay: 1000\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZXNvdXJjZXMvanMvdHlwZWQuanM/M2Y3MiJdLCJuYW1lcyI6WyJ0eXBlZCIsIlR5cGVkIiwic3RyaW5ncyIsInNtYXJ0QmFja3NwYWNlIiwidHlwZVNwZWVkIiwiYmFja1NwZWVkIiwibG9vcCIsInN0YXJ0RGVsYXkiXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0EsSUFBTUEsS0FBSyxHQUFHLElBQUlDLEtBQUosQ0FBVSxTQUFWLEVBQXFCO0FBQy9CQyxFQUFBQSxPQUFPLEVBQUUsQ0FBQyw0Q0FBRCxFQUErQywwQ0FBL0MsQ0FEc0I7QUFFL0JDLEVBQUFBLGNBQWMsRUFBRSxJQUZlO0FBRy9CQyxFQUFBQSxTQUFTLEVBQUUsRUFIb0I7QUFJL0JDLEVBQUFBLFNBQVMsRUFBRSxFQUpvQjtBQUsvQkMsRUFBQUEsSUFBSSxFQUFFLElBTHlCO0FBTS9CQyxFQUFBQSxVQUFVLEVBQUU7QUFObUIsQ0FBckIsQ0FBZCIsInNvdXJjZXNDb250ZW50IjpbIi8vIFRZUEVEXHJcbmNvbnN0IHR5cGVkID0gbmV3IFR5cGVkKCcjc2xvZ2FuJywge1xyXG4gICAgc3RyaW5nczogWydBIE5ldyBEaWZmZXJlbnQgV2F5IHRvIEltcHJvdmUgWW91ciBTa2lsbHMnLCAnTGV0XFwncyBKb2luIGFuZCBTdGFydCBHcm93aW5nIHdpdGggVXMuLi4nXSxcclxuICAgIHNtYXJ0QmFja3NwYWNlOiB0cnVlLFxyXG4gICAgdHlwZVNwZWVkOiA1MCxcclxuICAgIGJhY2tTcGVlZDogMzAsXHJcbiAgICBsb29wOiB0cnVlLFxyXG4gICAgc3RhcnREZWxheTogMTAwMCxcclxuXHJcbn0pO1xyXG4iXSwiZmlsZSI6Ii4vcmVzb3VyY2VzL2pzL3R5cGVkLmpzLmpzIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./resources/js/typed.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/js/typed.js"]();
/******/ 	
/******/ })()
;