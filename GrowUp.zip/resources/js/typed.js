// TYPED
const typed = new Typed('#slogan', {
    strings: ['A New Different Way to Improve Your Skills', 'Let\'s Join and Start Growing with Us...'],
    smartBackspace: true,
    typeSpeed: 50,
    backSpeed: 30,
    loop: true,
    startDelay: 1000,

});
